const API_KEY: "9abb4dd1-b5c7-411c-9ed7-c2b7c96e4f7c";

module.exports(){

  API_KEY: API_KEY,
}
